import tailwind from 'tailwindcss'

tailwind.config = {
  important: true,
};
