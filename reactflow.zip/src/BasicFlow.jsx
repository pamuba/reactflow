import { addEdge, applyEdgeChanges, applyNodeChanges, ReactFlow} from '@xyflow/react';
// import '@xyflow/react/dist/style.css';
import { useCallback, useState } from 'react';


const initialNodes = [
  {id : "1", position : {x : 0, y : 0}, data : {label : "Node 1"}},
  {id : "2", position : {x : 100, y : 100}, data : {label : "Node 2"}},
  {id : "3", position : {x : 0, y : 200}, data : {label : "Node 3"}}
 ]

const initialEdges = [
  {id : "e1-2", source : "1", target : "2", label : "Edge 1"},
  {id : "e2-3", source : "2", target : "3"},
  {id : "e1-3", source : "1", target : "3"}
]

function BasicFlow() {

const [nodes, setNodes] = useState(initialNodes);
const [edges, setEdges] = useState(initialEdges);
 
const onNodesChange = useCallback(
    (changes) => {
      // console.log("Changes" , changes )
      setNodes(
        (nodesSnapshot) => { 
          // console.log("Snapshot",nodesSnapshot)
          return applyNodeChanges(changes, nodesSnapshot)
        }
      )
    },
    [],
  );
  const onEdgesChange = useCallback(
    (changes) => setEdges((edgesSnapshot) => applyEdgeChanges(changes, edgesSnapshot)),
    [],
  );
  const onConnect = useCallback(
    
    (params) => {
      console.log(params)
      setEdges(
        (edgesSnapshot) => {
          console.log(edgesSnapshot)
          return addEdge(params, edgesSnapshot)
        }
      )
    },
    [],
  );
  
return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        fitView
      />
    </div>
  );
}

export default BasicFlow